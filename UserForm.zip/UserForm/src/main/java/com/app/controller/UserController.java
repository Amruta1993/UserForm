package com.app.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginController
 */
public class UserController extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String un = request.getParameter("Fname");
		String pw = request.getParameter("Lname");
		String bd = request.getParameter("bday");
		System.out.println(un + pw + bd);
		SimpleDateFormat availDate = new SimpleDateFormat("dd/MM/yyyy");
		Date chosenDate = null;
		try {
			chosenDate = availDate.parse(bd);

			Date d = new Date();
			int currentYear = d.getYear();
			int userYear = chosenDate.getYear();
			int userAge = currentYear - userYear;

			request.setAttribute("age", userAge);
			request.setAttribute("fname", un);
			request.getRequestDispatcher("welcome.jsp").forward(request, response);

		} catch (ParseException e) {
			e.printStackTrace();
		}
		// response.sendRedirect("welcome.");
		return;
	}
}
